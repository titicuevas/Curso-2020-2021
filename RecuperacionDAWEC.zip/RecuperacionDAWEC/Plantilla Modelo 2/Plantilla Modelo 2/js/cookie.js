function setCookie(cname, cvalue, exdays = 1) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}


function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function checkCookie() {
    var user = getCookie("username");
    if (user != "") {
        alert("Welcome again " + user);
    } else {
        user = prompt("Please enter your name:", "");
        if (user != "" && user != null) {
            setCookie("username", user, 365);
        }
    }
}

function deleteCookie(cnombre) {
    setCookie(cnombre, '', 0);
}


var menuArray = [];


function Menu(id, platos, precio) {
    this.id = id;
    this.platos = platos;
    this.precio = precio;

}


function mostrarAdmin() {

    var boton1 = document.createElement('button');
    boton1.textContent = 'Añadir';
    boton1.onclick = anadir;
    boton1.disabled = true;
    boton1.id = 'anadirBoton';
    var boton2 = document.createElement('button');
    boton2.textContent = 'Volver';

    var contenedorDos = document.getElementById('contenedorDos');

    var botonCliente = document.getElementById('entrarCliente');
    botonCliente.disabled = true;
    var botonAdmin = document.getElementById('entrarAdmin');

    botonAdmin.disabled = true;

    //var botonVolver = document.getElementById('volvere');
    //botonVolver.



    document.getElementById("contenedorDos").innerHTML =
        "<label for='nombre'>ID</label>" +
        "<input type='text' id='id' name='nombre' onblur='validar()'><br><br>" +
        "<label for='nombre'>Primer plato</label>" +
        "<input type='text' id='primerPlato' name='nombre' onblur='validar()'><br><br>" +
        "<label for='nombre'>Segundo plato</label>" +
        "<input type='text' id='segundoPlato' name='nombre' onblur='validar()'><br><br>" +
        "<label for='nombre'>Postre</label>" +
        "<input type='text' id='postre' name='nombre' onblur='validar()'><br><br>" +
        "<label for='nombre'>Precio</label>" +
        "<input type='text' id='precio' name='nombre' onblur='validar()'><br><br>";


    contenedorDos.appendChild(boton1);
    contenedorDos.appendChild(boton2);




}

function anadir() {
    var id = document.getElementById('id');
    var primerPlato = document.getElementById('primerPlato');
    var segundoPlato = document.getElementById('segundoPlato');
    var postre = document.getElementById('postre');
    var precio = document.getElementById('precio');



    var menus = document.getElementById('menus')

    var men = new Menu(id.value, primerPlato, segundoPlato, postre, precio);

    menuArray.push(men);


    var linea = document.createElement('span');

    var checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.onclick = seleccion;
    checkbox.value = menuArray.length - 1;

    var br = document.createElement('br');
    linea.textContent = id.value + '' + primerPlato.value + '' + segundoPlato.value + '' + postre.value + ''
    precio.value;



    console.log(menuArray);

    id.value = '';
    primerPlato.value = '';
    segundoPlato.value = '';
    postre.value = '';
    precio.value = '';

}


function seleccion() {
    elems = document.querySelectorAll("input[type=checkbox]:checked");
    var comprarBoton = document.getElementById('comprarBoton');

    if (elems.length) {
        comprarBoton.disabled = false;
    } else {
        comprarBoton.disabled = true;
    }
}


function comprar() {
    elems = document.querySelectorAll("input[type=checkbox]:checked");

    var total = 0;

    elems.forEach(element => {
        menuArray[element.value].precio -= 1;
        total += parseFloat(menuArray[element.value].precio);
        document.cookie = menuArray[element.value].plato + "=" + menuArray[element.value].precio;
    });

    alert("Debes" + precio + "euros");

    console.log(document.cookie);
}


function validar() {
    var id = document.getElementById('id');
    var primerPlato = document.getElementById('primerPlato');
    var segundoPlato = document.getElementById('segundoPlato');
    var postre = document.getElementById('postre');
    var precio = document.getElementById('precio');

    var botonAnadir = document.getElementById('anadirBoton');

    if (id.value && primerPlato.value && segundoPlato.value && postre.value && precio.value) {
        precioVal = parseFloat(precio.value);

        if (!isNaN(precioVal)) {
            // precioVal es numero decimal

            precioVal = parseInt(precio.value);

            if (!isNaN(precioVal)) {
                // stock es un numero entero

                botonAnadir.disabled = false;
            } else {
                botonAnadir.disabled = true;
            }
        } else {
            botonAnadir.disabled = true;
        }
    } else {
        botonAnadir.disabled = true;
    }
}




function mostrarCliente() {

    var boton12 = document.createElement('button');
    boton12.textContent = 'Comprar';
    boton12.onclick = comprar;
    boton12.disabled = true;
    boton12.id = 'comprarBoton';
    var boton22 = document.createElement('button');
    boton22.textContent = 'Volver';

    var contenedorDos = document.getElementById('contenedorDos');

    var botonCliente = document.getElementById('entrarCliente');
    botonCliente.disabled = true;
    var botonAdmin = document.getElementById('entrarCliente');

    var botonAdmin = document.getElementById('entrarAdmin');

    botonAdmin.disabled = true;




    botonAdmin.disabled = true;

    document.getElementById("contenedorDos").innerHTML =

        "<h3>id Primer Plato Segundo plato Postre Precio Seleccion </h3>"

    contenedorDos.appendChild(boton12);
    contenedorDos.appendChild(boton22);




}